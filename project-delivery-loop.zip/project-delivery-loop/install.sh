#!/usr/bin/env bash
# Install the project-delivery-loop skill + per-tool adapter files.
#
#   ./install.sh --repo /path/to/repo          # project scope (default)
#   ./install.sh --repo /path/to/repo --user   # also install for the user globally
#   ./install.sh --repo /path/to/repo --init-ledgers --name "My App" --offset +05:30
#   ./install.sh --repo /path/to/repo --dry-run
#
# Idempotent. Existing ledgers are never overwritten. Adapter blocks are fenced
# with markers, so re-running updates the block in place instead of duplicating.
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL="project-delivery-loop"
REPO=""; DO_USER=0; DO_INIT=0; DRY=0; NAME=""; OFFSET="+00:00"

while [ $# -gt 0 ]; do
  case "$1" in
    --repo) REPO="$2"; shift 2 ;;
    --user) DO_USER=1; shift ;;
    --init-ledgers) DO_INIT=1; shift ;;
    --name) NAME="$2"; shift 2 ;;
    --offset) OFFSET="$2"; shift 2 ;;
    --dry-run) DRY=1; shift ;;
    -h|--help) sed -n '2,12p' "$0"; exit 0 ;;
    *) echo "unknown arg: $1" >&2; exit 2 ;;
  esac
done

[ -n "$REPO" ] || { echo "error: --repo is required" >&2; exit 2; }
[ -d "$REPO" ] || { echo "error: not a directory: $REPO" >&2; exit 2; }
REPO="$(cd "$REPO" && pwd)"

run() { if [ "$DRY" = 1 ]; then echo "  [dry] $*"; else eval "$@"; fi; }

copy_skill() {  # $1 = destination skills dir
  local dest="$1/$SKILL"
  run "mkdir -p '$1'"
  run "rm -rf '$dest'"
  run "cp -R '$SRC' '$dest'"
  run "rm -f '$dest/install.sh' '$dest/install.ps1'"
  echo "  skill  -> $dest"
}

link_dir() {  # $1 = alias dir that should point at .agents/skills
  local alias_parent; alias_parent="$(dirname "$1")"
  run "mkdir -p '$alias_parent'"
  if [ -e "$1" ] && [ ! -L "$1" ]; then
    copy_skill "$1"
  else
    run "rm -f '$1'"
    run "ln -s '../.agents/skills' '$1' 2>/dev/null || cp -R '$REPO/.agents/skills' '$1'"
    echo "  alias  -> $1"
  fi
}

write_block() {  # $1 = target file, $2 = source adapter (fenced block appended/updated)
  local target="$1" src="$2"
  if [ "$DRY" = 1 ]; then echo "  [dry] write block -> $target"; return; fi
  mkdir -p "$(dirname "$target")"
  if [ -f "$target" ] && grep -q "BEGIN project-delivery-loop" "$target" 2>/dev/null; then
    python3 - "$target" "$src" <<'PY'
import re, sys, pathlib
t, s = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
block = s.read_text(encoding="utf-8")
m = re.search(r"<!-- BEGIN project-delivery-loop -->.*?<!-- END project-delivery-loop -->",
              block, re.S)
block = m.group(0) if m else block
new = re.sub(r"<!-- BEGIN project-delivery-loop -->.*?<!-- END project-delivery-loop -->",
             lambda _: block, t.read_text(encoding="utf-8"), flags=re.S)
t.write_text(new, encoding="utf-8")
PY
    echo "  update -> $target"
  elif [ -f "$target" ]; then
    printf '\n' >> "$target"; cat "$src" >> "$target"
    echo "  append -> $target"
  else
    cp "$src" "$target"
    echo "  create -> $target"
  fi
}

echo "Installing $SKILL into $REPO"
echo
echo "Skill (Agent Skills standard):"
copy_skill "$REPO/.agents/skills"
link_dir "$REPO/.claude/skills"
link_dir "$REPO/.codex/skills"
link_dir "$REPO/.github/skills"

echo
echo "Adapters (tools that read instruction files rather than skills):"
A="$SRC/adapters"
write_block "$REPO/AGENTS.md"                          "$A/AGENTS.md"
write_block "$REPO/CLAUDE.md"                          "$A/AGENTS.md"
write_block "$REPO/GEMINI.md"                          "$A/AGENTS.md"
write_block "$REPO/.github/copilot-instructions.md"    "$A/AGENTS.md"
write_block "$REPO/.windsurf/rules/delivery-loop.md"   "$A/AGENTS.md"
write_block "$REPO/.clinerules/delivery-loop.md"       "$A/AGENTS.md"
write_block "$REPO/.roo/rules/delivery-loop.md"        "$A/AGENTS.md"
write_block "$REPO/.amazonq/rules/delivery-loop.md"    "$A/AGENTS.md"
write_block "$REPO/.junie/guidelines.md"               "$A/AGENTS.md"
write_block "$REPO/.zed/rules.md"                      "$A/AGENTS.md"
write_block "$REPO/CONVENTIONS.md"                     "$A/AGENTS.md"
if [ "$DRY" = 1 ]; then
  echo "  [dry] create -> $REPO/.cursor/rules/delivery-loop.mdc"
else
  mkdir -p "$REPO/.cursor/rules"
  cp "$A/cursor-project-delivery-loop.mdc" "$REPO/.cursor/rules/delivery-loop.mdc"
  echo "  create -> $REPO/.cursor/rules/delivery-loop.mdc"
fi

if [ "$DO_USER" = 1 ]; then
  echo
  echo "User scope:"
  for d in "$HOME/.claude/skills" "$HOME/.codex/skills" "$HOME/.agents/skills"; do
    copy_skill "$d"
  done
fi

if [ "$DO_INIT" = 1 ]; then
  echo
  echo "Ledgers:"
  ARGS="--root '$REPO' --offset '$OFFSET'"
  [ -n "$NAME" ] && ARGS="$ARGS --name '$NAME'"
  run "python3 '$SRC/scripts/ledger_init.py' $ARGS"
fi

cat <<TXT

Done.

Next:
  1. Commit these files - the loop is only shared if the repo carries it.
  2. If this is an existing project, reconstruct MEMORY.md from the codebase
     rather than leaving the template, and file it as T-0001.
  3. Verify with:
       python3 .agents/skills/$SKILL/scripts/ledger_check.py --root .
TXT

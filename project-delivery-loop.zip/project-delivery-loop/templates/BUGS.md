# BUGS — <PROJECT NAME>
_Newest first. OPEN entries never rotate out._
_Status: OPEN · CONFIRMED · IN_PROGRESS · FIXED · WONTFIX · CANNOT_REPRODUCE_
_Severity: S1 data loss/security/outage · S2 core broken, no workaround · S3 workaround exists · S4 cosmetic_

## B-0001 — <title>
- Found:      <ts> by <author> (<during T-xxxx testing | reported by user>)
- Status:     OPEN
- Severity:   S3
- Repro:      <exact steps, environment, commit sha, reproducibility rate>
- Expected:   <what should happen>
- Actual:     <what happens>
- Root cause: <the mechanism, not the symptom>
- Fix:        <C-xxxx (T-xxxx) or ->
- Regression: <test that fails on the pre-fix code>
- Siblings:   <same root cause elsewhere -> T-xxxx>
- Closed:     <ts or ->

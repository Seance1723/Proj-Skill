# DECISIONS — <PROJECT NAME>
_Newest first. Required for T2/T3 and for every rejection._
_Status: ACCEPTED · REJECTED · REJECTED_FOR_NOW · SUPERSEDED_BY_D-00xx_
_A rejection entry is as valuable as an acceptance: it stops the same idea returning as a fresh insight._

## D-0001 — <question in one line>
- When:     <ts> | Author: <> | Task: T-xxxx
- Status:   ACCEPTED
- Question: <what was actually being decided>
- Options:
  | Approach | Who does it this way | Fits our stack? | Cost | What we'd skip |
  |---|---|---|---|---|
  | <A> | <> | <> | <> | <> |
  | Do nothing / reuse <X> | — | — | 0 | — |
- Decision: <what was chosen>
- Gate:     1 <traceable> · 2 <not already solved> · 3 <minimal form> · 4 <dependency> · 5 <rule of three> · 6 <reversible>
- Revisit:  <the trigger that would reopen this>
- Sources:  <the 2-3 that actually moved the decision>

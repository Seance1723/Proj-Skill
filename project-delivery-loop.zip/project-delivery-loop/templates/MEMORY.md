# MEMORY — <PROJECT NAME>
_Last updated: <ISO-8601 with offset> by <author>_
_Cap: 400 lines. This is a snapshot, not a diary. Detail lives in DECISIONS.md and references._

## What this is
<2-4 sentences: what the app does, for whom, maturity (prototype / internal beta / production since <date>).>

## Current state
- Branch / version: <>
- Works: <>
- Half-built: <>
- Known broken: <B-xxxx, B-xxxx>
- Deployed: <where, how, last deploy ts>

## Stack and topology
- Language / runtime: <>
- Framework: <>
- Datastore: <>
- Hosting / CI: <>
- External services: <service — what it is used for>

## How to run it
- Install: `<cmd>`
- Dev: `<cmd>`
- Test: `<cmd>`
- Build: `<cmd>`
- Deploy: `<cmd>`
- Env vars: NAMES ONLY — see `.env.example`. Never record values here.

## Map
| Path | Responsibility |
|---|---|
| `<dir>` | <what lives here> |

Entry points: <>
Routes: <> · Models: <> · Migrations: <> · Tests: <>

## Invariants
- <thing that must stay true> — breaks <what> if violated.

## Gotchas
- <non-obvious trap that cost someone an hour>

## Glossary
- **<term>** — <meaning in the project's own words>

## Open threads
- Active: <T-xxxx>
- Blocked: <T-xxxx — why>
- Next action: <the single next thing>

## Pointers
- Work queue: `TASKS.md` · History: `CHANGES.md` · Defects: `BUGS.md` · Rulings: `DECISIONS.md`
- Archive: `docs/agent-archive/`
- Key decisions: <D-xxxx: title>

# CHANGES — <PROJECT NAME>
_Append-only, newest first. Never edit a past entry; corrections are new entries referencing the old ID._
_Rotate at 50 entries / 1500 lines via `scripts/ledger_rotate.py`._

## C-0001 — <title>
- When:    <ts>
- Author:  <model or human>
- Task:    T-0001 | Tier: T1 | Decision: —
- Commit:  <sha>
- What:    <what changed, concretely>
- Why:     <the need it serves; link B- or T- id>
- Files:   <paths touched>
- Verification:
  - `<command>` -> <observed result>
  - Manual: <steps actually performed> -> <what was seen>
  - Not covered: <the honest edge of verification> -> <T-xxxx if follow-up>
- Follow-ups: <T-xxxx or ->

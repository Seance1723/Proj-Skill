# TASKS — <PROJECT NAME>
_Status vocabulary: BACKLOG · PLANNED · IN_PROGRESS · BLOCKED · IN_REVIEW · DONE · DROPPED_
_Tiers: T0 trivial · T1 standard · T2 significant · T3 irreversible/hazardous_
_Claim a task by setting Owner + IN_PROGRESS + Updated before the first edit._

## Active

### T-0001 — <title>
- Status:      PLANNED
- Tier:        T1
- Owner:       —
- Created:     <ts>
- Updated:     <ts>
- Depends:     —
- Decision:    —
- Ask:         <restated, including what is implied>
- Assumptions: <stated defaults for non-blocking ambiguities>
- Scope fence: <files/dirs this task may touch>
- Out of scope:<adjacent things deliberately not being done>
- Acceptance:  <observable criteria>
- Notes:       <amendments, blockers, what was ruled out>

## Queued

## Recently done (last 20 — full history in CHANGES.md)

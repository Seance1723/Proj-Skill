# 01 — Intake, Tiering and Sequencing

Contents: [Risk tiers](#risk-tiers) · [Decomposition](#decomposition) ·
[Sequencing](#sequencing) · [Ambiguity handling](#ambiguity-handling) ·
[Plan block](#plan-block)

## Risk tiers

Tier is chosen by **blast radius and reversibility**, not by how many lines of
code it takes. A three-line change to a payment webhook is T3. A 400-line new
settings page is T1.

### T0 — Trivial
Typos, copy edits, comments, formatting, a config value with no behavioural
effect, a patch-level dependency bump with a clean changelog.

- Research: skip. Necessity gate: skip.
- `TASKS.md`: optional — T0s may be batched into one entry per session.
- `CHANGES.md`: one line, batched is fine.
- Verify: build passes.

### T1 — Standard
A bug fix, a small feature inside an existing module, a contained refactor, a UI
change with no data-model impact.

- Research: inward always; outward ≤5 sources if there is a known-good pattern.
- Necessity gate: yes, briefly.
- Approval: not required.
- Verify: unit tests for changed logic + full suite + manual smoke if UI.

### T2 — Significant
A new module or service, a new dependency, a schema or migration, a new external
integration, an auth/permissions change, a cross-cutting refactor, anything that
changes a public contract (API shape, URL, event payload, CLI flag).

- Research: full, ≤10 sources, comparison table required.
- Necessity gate: written out, all six criteria answered.
- `DECISIONS.md` entry: **required**.
- Approval: **required before implementation.** Present the plan block and wait.
- Verify: unit + integration + the negative cases + full suite + smoke.

### T3 — Irreversible or hazardous
Production data migration or deletion, billing/pricing logic, secrets rotation,
infra teardown, anything touching customer PII, anything that cannot be undone
with a revert.

Everything in T2, plus:
- A written rollback plan with the exact restore command, tested where possible.
- A backup taken and its location recorded (never the backup's credentials).
- Staged rollout or a dry-run mode first where the medium allows.
- Explicit written go-ahead from the owner naming the action.

**When torn between two tiers, take the higher one.** The cost of over-tiering is
one extra paragraph of writing. The cost of under-tiering is the incident.

## Decomposition

Split until each unit is:

- **Independently shippable** — merging it alone leaves the app working.
- **Independently testable** — it has an observable acceptance criterion.
- **One-sitting sized** — if you cannot finish it before context runs out, split
  it again. A half-finished unit is the thing that destroys handoffs.

Vertical slices beat horizontal layers. "Login end-to-end for email users" is a
better unit than "all the database work, then all the API work, then all the
UI" — the horizontal version has no shippable midpoint and no way to prove the
early layers are right until the end.

Two useful splits when a unit is too big:
- **Happy path first, edge cases second.** Ship the working case, then harden.
- **Read before write.** Display the data, then let users change it.

## Sequencing

Order by, in priority:

1. **Hard dependency** — B cannot compile, run, or be tested without A.
2. **Risk front-loading** — the unknown, load-bearing, or externally dependent
   piece goes early, while abandoning the plan is still cheap. Discovering on
   day four that the third-party API cannot do the thing is a planning failure,
   not bad luck.
3. **Unblocking** — what other people or other tasks are waiting on.
4. **Reversibility** — reversible before irreversible; never run the migration
   before the code that needs it is proven.

Always state the *reason* for each ordering constraint. A sequence without
reasons cannot be safely re-ordered later when reality intervenes.

Record dependencies as task IDs (`Depends: T-0041`), not prose, so the ledger
stays machine-checkable.

## Ambiguity handling

Sort every ambiguity into two buckets:

- **Design-changing** — the answer changes the schema, the contract, the
  dependency, or the scope. Ask. One message, batched, options offered.
- **Everything else** — pick a sensible default, state it explicitly as a stated
  assumption, and proceed. Do not stall a whole change on a button colour.

Write the assumptions into the task entry. Unstated assumptions are the thing
the next agent silently inherits and the owner later discovers.

## Plan block

Present this verbatim for T2/T3, and as a two-line summary for T1.

```
PLAN — <short title>
Tier:         T2
Ask:          <restated in your words, incl. what is implied>
Assumptions:  <stated defaults for non-blocking ambiguities>
Units:        T-0042 <unit>  (depends: —)
              T-0043 <unit>  (depends: T-0042)
Scope fence:  <exact files/dirs that will be touched>
Out of scope: <the adjacent things you are deliberately not doing>
Prior art:    <what you found, and what you are deliberately not copying>
Risks:        <what could break, and the early warning sign>
Rollback:     <how this is undone>
Acceptance:   <observable criteria, one per unit>
Awaiting go-ahead before implementation.
```

The "Out of scope" line does more work than any other. It is where the
over-engineering that survived the necessity gate goes to be named and dropped,
and it is what stops scope drift mid-implementation — you can point at it.

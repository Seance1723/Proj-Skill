# 05 — Multiple Agents, Hygiene, Portability

Contents: [Concurrent agents](#concurrent-agents) · [Merge-conflict avoidance](#merge-conflict-avoidance)
· [Handoff block](#handoff-block) · [Secret hygiene](#secret-hygiene) ·
[Context budget](#context-budget) · [Cross-tool portability](#cross-tool-portability)

## Concurrent agents

Several agents (and humans) may work the same repo, sometimes simultaneously,
often unaware of each other.

**Claim before you work.** Set `Owner` and `Status: IN_PROGRESS` with a timestamp
before the first edit. An unclaimed task is fair game; a claimed one is not.

**Respect a live claim.** If a task is `IN_PROGRESS` under another owner and the
`Updated` timestamp is recent, do not start it. Pick another task or ask. If the
claim is stale (no update in ~24h and no branch activity), you may take it over —
but say so in `Notes` with a timestamp rather than silently overwriting.

**Never rewrite someone else's entry.** Append your own. Corrections reference
the original ID. The history is the product.

**Split by module, not by file.** Two agents in the same file conflict; two
agents in the same subsystem trip over each other's assumptions. Sequence tasks
that share a fence rather than parallelising them.

## Merge-conflict avoidance

Ledgers are hot files. Reduce friction:

- Write once per phase, not continuously. Batch a task's ledger updates into a
  single edit at P8.
- Keep entries self-contained blocks separated by blank lines, so git can merge
  neighbouring additions cleanly.
- Never reformat, re-sort, or re-number the whole file — that turns a two-line
  addition into a total conflict.
- If a conflict does happen: keep **both** entries. Two records of real work
  beat one tidy file.
- Ledger updates ride in the same commit as the code they describe. Split
  commits let the history and the code drift apart.

## Handoff block

Post this at the end of every session, and paste it into the task's `Notes` if
work is unfinished. Handoff quality is the single biggest predictor of whether
the next session starts productively or starts over.

```
HANDOFF — <ts>
Branch:        feat/otp-rate-limit
Tree:          clean | uncommitted: src/api/otp/verify.ts (partial)
Done:          T-0042 → DONE (C-0031)
Open:          T-0051 (queued), T-0052 (queued)
Blocked:       —
Next action:   Start T-0051; needs a decision on whether we run >1 instance
Learned:       The limiter middleware isn't auto-applied to routes registered
               after boot — anything new must register explicitly. Now in
               MEMORY.md → Gotchas.
```

The `Learned` line is where tacit knowledge gets caught before it evaporates. If
something surprised you, it belongs in `MEMORY.md → Gotchas` or `Invariants`.

## Secret hygiene

Ledgers get committed, shared, and pasted into other agents' context windows.

Never write into any ledger, commit message, or log:

- API keys, tokens, passwords, private keys, session cookies
- `.env` values, connection strings, webhook signing secrets
- Customer PII: real names, emails, phone numbers, addresses, payment details
- Stack traces or request dumps containing any of the above
- Internal URLs with embedded credentials

Do write: env var **names**, the shape of a config, redacted samples
(`+91-XXXXX-XX042`), and synthetic examples. Use `<redacted>` explicitly rather
than silently dropping a field — the reader should know something was removed.

When a bug report needs real data to be understandable, describe the *shape*
("a phone number with a leading zero"), never the value.

If a secret has already been committed, that is an S1: rotate the credential
first, then scrub. Rotation before scrubbing, always — the scrub is cosmetic
until the key is dead.

## Context budget

This workflow only pays off if the artefacts stay readable.

- P0 orientation should cost a few thousand tokens, not tens of thousands. That
  is what the caps in reference 04 are for.
- Prefer linking IDs over restating content. Never copy a decision's body into a
  task; reference `D-0009`.
- If you find yourself skimming the ledgers instead of reading them, they are
  too big — rotate now, before writing more.
- Long sessions drift. Re-read the active task entry before P5 and again before
  P8; the scope fence you wrote an hour ago is the one you are most likely to
  have quietly abandoned.

## Cross-tool portability

The same loop is expected to run under different agents. Keep the artefacts
tool-neutral:

- Plain Markdown, no tool-specific syntax in ledgers.
- Never reference a tool's UI affordances ("click Accept") — describe commands.
- Ledgers are the source of truth about the project; the skill and the adapter
  files are the source of truth about the process. Do not mix them: project
  facts never belong in `SKILL.md`, and process rules never belong in
  `MEMORY.md`.
- If a tool cannot load skills, its adapter file (see `adapters/`) carries the
  non-negotiable core inline, so the loop degrades gracefully rather than
  vanishing.
- Model differences are real. A smaller model will follow the phase list but skim
  the references — keep phase names and hard rules in the adapter text itself so
  the essentials survive without the reference files being loaded.

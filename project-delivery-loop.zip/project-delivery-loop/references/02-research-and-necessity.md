# 02 — Research and the Necessity Gate

Contents: [Why research first](#why-research-first) · [Inward research](#inward-research-the-repo)
· [Outward research](#outward-research-the-world) · [Budget and stopping rule](#budget-and-stopping-rule)
· [Comparison table](#comparison-table) · [Necessity gate](#the-necessity-gate)
· [Worked examples](#worked-examples) · [Recording the outcome](#recording-the-outcome)

## Why research first

Two distinct wins, and it is worth being clear which you are chasing:

1. **Don't re-invent.** Someone shipped this and hit the failure modes already.
2. **Don't over-build.** Seeing what mature products *omit* at your scale is the
   fastest cure for gold-plating. Most successful implementations are smaller
   than the one you were about to design.

Research that is not written down is research you will do again next session.
The output of this phase is a `DECISIONS.md` entry, not a feeling.

## Inward research (the repo)

Always first, always cheaper. Before looking at how the world does it, establish
what you already have:

- Grep for the domain nouns and verbs, not just the feature name.
- List candidate existing modules, helpers, hooks, middlewares, migrations.
- Read the two most similar existing features end-to-end. Match their seams,
  naming, error handling, and test style — consistency with the codebase beats
  correctness in the abstract, because the next reader only knows one of them.
- Check `DECISIONS.md` for prior rulings on this exact area. If the thing was
  rejected before, the burden is to show what changed.

A change that fits an existing seam is almost always the right answer, even when
a cleaner greenfield design exists.

## Outward research (the world)

Look for, in order of usefulness:

1. **Failure reports** — post-mortems, issue threads, "what we got wrong"
   write-ups. The highest-signal source by a wide margin.
2. **Reference implementations** — how a mature open-source project in the same
   space actually structures it.
3. **Official docs** for anything you will depend on, especially limits, quotas,
   and error semantics.
4. Tutorials last. They optimise for looking simple, not for surviving.

For each source capture: what they do, why, what it costs, and what part of it
you do not need. That last column is the whole point.

## Budget and stopping rule

| Tier | Sources | Wall-clock guide |
|---|---|---|
| T0 | 0 | — |
| T1 | ≤5 | ~10 min |
| T2 | ≤10 | ~30 min |
| T3 | ≤15 | ~60 min |

Stop early when two consecutive sources add nothing new — that is saturation and
further reading is procrastination. Stop hard at the budget: if you are still
uncertain at the limit, that uncertainty is itself the finding. Write it down,
name the smallest experiment that would resolve it (a spike, a prototype, one
API call), and put *that* in `TASKS.md` instead of reading an eleventh article.

## Comparison table

Required for T2/T3, in the `DECISIONS.md` entry:

| Approach | Who does it this way | Fits our stack? | Cost | What we'd skip |
|---|---|---|---|---|
| A | … | … | … | … |
| B | … | … | … | … |
| Do nothing / reuse X | — | … | 0 | — |

**"Do nothing" or "reuse what exists" is a mandatory row.** Omitting it is how
the necessity gate gets quietly bypassed.

## The necessity gate

Six criteria. All must pass. Answer them in writing for T2/T3, in one line each
for T1.

### 1. Traceable
Points to a stated need, an open bug, a measured problem, or an explicit request.
Fails on: "might be useful later", "best practice says", "every app has one".

### 2. Not already solved
You have read the candidate modules and can name why each is insufficient. Fails
on: "I didn't check" and on rebuilding something that a config change unlocks.

### 3. Minimal form
Name the bigger version you are deliberately not building. If you cannot name a
bigger version, you have not thought about the boundary.

### 4. Dependency justified
A new dependency must remove ≥100 lines you would otherwise write and maintain,
or be security-critical (crypto, auth, parsing, protocol handling — write those
yourself only with a very good reason). Weigh install size, transitive tree,
maintenance status, and the cost of removing it later.

### 5. Rule of three
No new abstraction, base class, plugin system, config layer, or generic
"framework" until the third real repetition. Two similar things are a
coincidence. Premature abstraction costs more than duplication, and duplication
is trivially fixable later while a wrong abstraction is not.

### 6. Reversible
State how it is undone. If undoing is expensive or impossible, re-tier to T3 and
require a rollback plan.

## Worked examples

**Ask: "add caching to the dashboard."**
Gate 1 — is it slow? No measurement exists. → Fails traceability. The real task
is `T-00xx Measure dashboard load and find the actual bottleneck`. Log the cache
idea as `DECISIONS.md` REJECTED-FOR-NOW with "revisit if p95 > 1.5s". Nine times
in ten the bottleneck is one unindexed query, and the cache would have hidden it.

**Ask: "make the export system pluggable so we can add formats later."**
Gate 5 — there is one format today, CSV. → Fails rule of three. Ship the CSV
export as a plain function. When the third format arrives, the shape of the
abstraction will be obvious instead of guessed.

**Ask: "add rate limiting to the OTP endpoint."**
Gate 1 passes (abuse is a real, known attack on OTP). Gate 2 — check whether the
framework or the reverse proxy already provides it; often it does, and the answer
is ten lines of config, not a module. Gate 3 — minimal form is per-phone and
per-IP counters with a fixed window; the version you are not building is a
distributed sliding-window limiter with its own store. Gate 4 — if the framework
gives it, no new dependency at all. Passes → proceed at T2 (touches auth).

## Recording the outcome

Every research phase ends with a `DECISIONS.md` entry, including — especially —
the ones that end in "no". A rejection entry with a clear reason and a revisit
trigger saves the next agent an hour and saves the codebase a subsystem.

Minimum contents: the question, options considered with the comparison table,
the decision, the six-criteria verdict, the revisit trigger, and links to the
two or three sources worth re-reading. Not a bibliography — the ones that
actually moved the decision.

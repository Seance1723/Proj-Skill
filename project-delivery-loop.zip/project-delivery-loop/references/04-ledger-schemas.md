# 04 — Ledger Schemas

Contents: [Conventions](#conventions) · [MEMORY.md](#memorymd) · [TASKS.md](#tasksmd)
· [CHANGES.md](#changesmd) · [BUGS.md](#bugsmd) · [DECISIONS.md](#decisionsmd)
· [Rotation](#rotation-and-archiving)

## Conventions

- **Location**: repo root by default. Archives in `docs/agent-archive/`.
- **Timestamps**: ISO-8601 with offset — `2026-08-20T14:32:05+05:30`. One offset
  for the whole project, forever.
- **IDs**: `T-0001` task, `C-0001` change, `B-0001` bug, `D-0001` decision.
  Zero-padded to four, monotonic, never reused, never renumbered even after
  deletion — a dead ID is better than an ambiguous one.
- **Order**: newest entries at the top of `CHANGES.md`, `BUGS.md`,
  `DECISIONS.md`. A cold reader should hit the present, not 2024.
- **Author**: every entry names its author — model or human.
- **Cross-links**: always by ID (`T-0042`, `B-0007`), never by prose reference.

## MEMORY.md

The cold-start briefing. **Rewritten in place, hard cap 400 lines.** Its job is
to be short enough that the next agent actually reads it — the moment it becomes
a diary it stops being read, and then nothing else in this system works.

Sections, in order:

```markdown
# MEMORY — <Project>
_Last updated: <ts> by <author>_

## What this is
2–4 sentences. What the app does, for whom, and its current maturity
(prototype / internal beta / in production since <date>).

## Current state
Version/branch, what works, what is half-built, what is known broken
(link bug IDs), what is deployed and where.

## Stack and topology
Languages, frameworks, datastore, hosting, external services and what each is
for. Note versions only where a version constraint actually bites.

## How to run it
Install, dev, test, build, deploy — exact commands. Required env vars by NAME
only, never values. Point to `.env.example`.

## Map
Directory → responsibility. Entry points. Where routes, models, migrations,
config, and tests live. Just enough to navigate without a grep safari.

## Invariants
Things that must stay true, and what breaks if they don't. E.g. "all money is
integer paise, never float"; "tenant_id is required on every query".
This section prevents more damage than any other.

## Gotchas
Non-obvious traps a newcomer would hit. The thing that took someone an hour.

## Glossary
Project-specific nouns, in the user's words.

## Open threads
Active tasks, blocked tasks, the single next action. Links to IDs only.

## Pointers
Where the detail lives: TASKS/CHANGES/BUGS/DECISIONS, key ADR IDs, external docs.
```

Update rule: refresh only what reality changed. If a change did not alter state,
stack, map, invariants, or open threads, `MEMORY.md` does not move.

## TASKS.md

Edited in place. Three sections: **Active** (`IN_PROGRESS`, `BLOCKED`,
`IN_REVIEW`), **Queued** (`BACKLOG`, `PLANNED`), **Recently done** (last 20,
one line each; older ones live in `CHANGES.md`).

```markdown
### T-0042 — Rate-limit the OTP verify endpoint
- Status:     IN_PROGRESS        <!-- BACKLOG|PLANNED|IN_PROGRESS|BLOCKED|IN_REVIEW|DONE|DROPPED -->
- Tier:       T2
- Owner:      Claude Opus 5      <!-- who has claimed it -->
- Created:    2026-08-20T09:14:02+05:30
- Updated:    2026-08-20T11:02:41+05:30
- Depends:    T-0041
- Decision:   D-0009
- Ask:        <restated, incl. what is implied>
- Assumptions:<stated defaults for non-blocking ambiguities>
- Scope fence:`src/api/otp/*`, `src/middleware/rateLimit.ts`, `tests/otp/*`
- Out of scope:distributed limiter, admin override UI
- Acceptance: 6th request in 60s from one number → 429 with Retry-After;
              valid code within window still succeeds; counters reset on success
- Notes:      <amendments, blockers, what was ruled out>
```

`DROPPED` requires a reason and, if it was dropped on principle, a `D-` link so
it is not silently re-proposed.

## CHANGES.md

Append-only, newest first. One entry per completed task (T0s may be batched).

```markdown
## C-0031 — Rate limiting on OTP verify
- When:    2026-08-20T11:58:03+05:30
- Author:  Claude Opus 5
- Task:    T-0042  | Tier: T2 | Decision: D-0009
- Commit:  a3f19c2
- What:    Fixed-window counters per phone and per IP on POST /otp/verify,
           returning 429 + Retry-After. Counters in existing Redis client.
- Why:     Repeated-guess abuse observed in logs (B-0012).
- Files:   src/api/otp/verify.ts, src/middleware/rateLimit.ts, tests/otp/rate.test.ts
- Verification:
  - `npm run build` → passed
  - `npm test` → 212 passed, 1 skipped (pre-existing, B-0007)
  - Manual: 6 requests in 40s → 429 on 6th, Retry-After 47
  - Not covered: multi-instance counter drift (single instance today) → T-0051
- Follow-ups: T-0051
```

Never edit a past entry. Corrections are new entries that reference the old ID.
An append-only history is the only kind that can be trusted.

## BUGS.md

Newest first. `OPEN` entries stay in the file regardless of age.

```markdown
## B-0012 — OTP verify accepts unlimited guesses
- Found:      2026-08-20T09:02:11+05:30 by Claude Opus 5 (during T-0041 testing)
- Status:     FIXED          <!-- OPEN|CONFIRMED|IN_PROGRESS|FIXED|WONTFIX|CANNOT_REPRODUCE -->
- Severity:   S2             <!-- S1 data loss/security/outage · S2 core broken · S3 workaround · S4 cosmetic -->
- Repro:      POST /otp/verify with a wrong code, repeat 50×, all return 400 and
              none throttle. 100% reproducible on main @ 8c21e0f.
- Expected:   Throttled after a small number of attempts.
- Root cause: The endpoint was added after the limiter middleware was written and
              was never registered with it; no test covered the unhappy path.
- Fix:        C-0031 (T-0042)
- Regression: tests/otp/rate.test.ts::blocks_after_five_failures — fails on 8c21e0f
- Siblings:   /otp/resend has the same gap → T-0052
- Closed:     2026-08-20T11:58:03+05:30
```

`WONTFIX` needs a reason and, where relevant, a `D-` link.

## DECISIONS.md

Newest first. Written for T2/T3, for any rejection, and any time a choice will
look arbitrary in three months.

```markdown
## D-0009 — How to rate-limit OTP verification
- When:     2026-08-20T10:31:00+05:30 | Author: Claude Opus 5 | Task: T-0042
- Status:   ACCEPTED       <!-- ACCEPTED|REJECTED|REJECTED_FOR_NOW|SUPERSEDED_BY_D-00xx -->
- Question: How do we stop brute-force guessing without breaking legitimate retries?
- Options:
  | Approach | Who does it | Fits stack? | Cost | What we'd skip |
  |---|---|---|---|---|
  | Fixed window in existing Redis | common baseline | yes | ~60 LOC | — |
  | Sliding-window library | high-traffic services | new dep | dep + config | not needed at our scale |
  | Reuse existing nginx limiter | — | partly | 0 | can't key by phone |
  | Do nothing | — | — | 0 | — |
- Decision: Fixed window, keyed by phone and IP, in the existing Redis client.
- Gate:     1 traceable (B-0012) · 2 nginx can't key by phone · 3 not building a
            distributed limiter · 4 no new dep · 5 n/a · 6 revertible in one commit
- Revisit:  If we run multiple API instances, or abuse continues past the window.
- Sources:  <2–3 that actually moved the decision>
```

A `REJECTED` entry is as valuable as an accepted one. Its purpose is to stop the
same idea arriving next session dressed as a fresh insight.

## Rotation and archiving

Unbounded ledgers defeat themselves: they blow the context budget and the next
agent skims instead of reads.

| File | Cap | On exceeding |
|---|---|---|
| `MEMORY.md` | 400 lines | Push detail out to references; keep the snapshot |
| `TASKS.md` | 20 recent-done | Older done rows drop (they live in `CHANGES.md`) |
| `CHANGES.md` | 50 entries / 1500 lines | Rotate oldest to archive |
| `BUGS.md` | all OPEN + 20 closed | Rotate older closed to archive |
| `DECISIONS.md` | keep all ACCEPTED | Rotate SUPERSEDED to archive |

Rotate with `python3 scripts/ledger_rotate.py --root <repo>`. It moves entries
to `docs/agent-archive/<FILE>-<YYYY>-Q<n>.md` and leaves a one-line stub with
the ID range and archive path, so no ID ever becomes unfindable.

Rotate in batches at the threshold, never one entry at a time — a churning
ledger is a noisy diff.

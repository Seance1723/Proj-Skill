# 03 — Implement, Verify, Recover

Contents: [Scope fence](#scope-fence) · [Implementation rules](#implementation-rules)
· [Test tiers](#test-tiers) · [Evidence format](#evidence-format) ·
[Defect protocol](#defect-protocol) · [Blocked and rollback](#blocked-and-rollback)
· [Definition of done](#definition-of-done)

## Scope fence

Each task declares the files and directories it may touch. The fence exists
because unbounded edits are what make a change unreviewable and a revert
impossible.

- Need a file outside the fence? Amend the task entry with the file and a
  one-line reason, then continue. The amendment is the whole cost — this is not
  a blocker, it is a record.
- Refactoring an untouched module because it offended you is out of scope even
  when you are right. `TASKS.md`, T1, move on.
- Never reformat a file you are not otherwise changing; it drowns the diff.

## Implementation rules

- **One task `IN_PROGRESS` at a time**, owner set, timestamped. Parallel
  half-finished tasks are how state gets lost between sessions.
- **Match the codebase, not your preferences.** Same error handling, same
  logging, same naming, same test style as the two nearest existing features.
- **Commit per task**: `type(scope): summary [T-0042]`. Types: feat, fix,
  refactor, perf, docs, test, chore, revert. The task ID in the message is what
  lets `ledger_check` tie the ledger to git history.
- **Never fabricate progress.** Do not report a command as run that you did not
  run, a test as passing that you did not see pass, or a file as created that
  you did not create. If you are unsure whether something worked, say so and
  check. A ledger that is 95% true is worse than no ledger, because it is
  trusted.
- **Leave the tree green.** If you must stop mid-task, commit to a branch with a
  `WIP [T-0042]` message and record the exact state in the handoff block.

## Test tiers

Run every tier that applies. "Thoroughly" means the list below, not a feeling.

| Tier | What | When |
|---|---|---|
| Build | Compile / typecheck / lint | Always, including T0 |
| Unit | Changed logic, incl. its failure branches | Any logic change |
| Integration | The seam you touched: route ↔ handler ↔ store | T2+, any contract change |
| Regression | A test that fails on the old code | Every bug fix, no exceptions |
| Negative | Bad input, empty state, unauthorised, timeout, duplicate submit | T2+ |
| Full suite | Everything, not just your file | Always before `DONE` |
| Smoke | The actual user path, clicked or curled | Any user-facing change |
| Data | Migration up **and** down on a copy of real-shaped data | T3 |

Non-negotiables:

- **Never weaken a test to get green.** No deleting assertions, no `skip`, no
  widening a mock, no loosening a matcher to make a real failure disappear. If a
  test is genuinely wrong, changing it is a decision — write it in
  `DECISIONS.md` with the reasoning, do not bury it in a diff.
- **A fix without a regression test is not a fix.** Write the failing test first
  where practical; at minimum verify it fails against the pre-fix code.
- **No test infrastructure yet?** Record the manual verification steps and their
  actual output, then create a task to add the missing harness. Manual evidence
  is acceptable; absent evidence is not.

## Evidence format

Goes into the `CHANGES.md` entry. Commands and observed results, not adjectives.

```
Verification:
- `npm run build` → passed (0 errors)
- `npm test -- otp` → 14 passed, 0 failed
- `npm test` (full) → 212 passed, 1 skipped (pre-existing, see B-0007)
- Manual: requested OTP 6× in 40s from one number → 6th returned 429,
  `Retry-After: 47`; correct code on attempt 3 still succeeded
- Not covered: SMS provider outage path (no sandbox) → T-0051
```

The "Not covered" line matters as much as the passes. It is the honest edge of
what was verified, and it is what stops a later reader assuming more coverage
than exists.

## Defect protocol

1. **Log before fixing.** A `BUGS.md` entry exists before the fix, even for a
   30-second fix, or the trace of what was wrong disappears.
2. **Root cause, not symptom.** "Null check added" is a symptom. "The provider
   returns `{}` on timeout rather than an error, so `.id` was undefined" is a
   root cause. Only the second one tells you where else the same bug lives.
3. **Check for siblings.** Same root cause elsewhere in the codebase? Log them
   now, even if you fix them later.
4. **Regression test.** Always.
5. **In scope or out?** A defect inside the current task's fence gets fixed in
   the task. Anything else becomes a new task with its own tier. A bug is never
   a licence to expand a change — that is how a one-file fix becomes an
   unreviewable 40-file diff.
6. **User-reported defects** enter at the same door: `BUGS.md` first, then
   triage into `TASKS.md` by severity.

Severity: **S1** data loss, security, or total outage → drop everything.
**S2** core flow broken, no workaround. **S3** broken with a workaround.
**S4** cosmetic or rare.

## Blocked and rollback

Stop and escalate when any of these hit:

- Three failed fix attempts at the same defect.
- The fix requires a change the owner has not approved (new dependency, schema
  change, contract break).
- Tests cannot pass without weakening them.
- You are less sure of the design now than when you started.

The stop protocol: revert the working tree to the last green commit (or stash to
a named branch), set the task `BLOCKED`, and write **what you tried, what you
ruled out, and what you now believe the real problem is**. That last sentence is
the valuable one — a blocked task with good notes is a gift to the next session;
a blocked task saying "didn't work" wastes it entirely.

For T3, rollback is planned before implementation, not improvised after: the
exact restore command, where the backup lives, and how you will confirm the
restore worked.

## Definition of done

A task moves to `DONE` only when all are true:

- [ ] Acceptance criteria met and demonstrated, not assumed
- [ ] All applicable test tiers run, with evidence recorded
- [ ] Full suite green, or every failure explained and linked to a bug ID
- [ ] No test weakened or skipped to achieve green
- [ ] Defects found are logged, with fixes carrying regression tests
- [ ] Docs updated where behaviour changed — README, API docs, `.env.example`,
      migration notes. **Doc drift is a defect**, and it is the one that silently
      breaks the next person's setup
- [ ] `CHANGES.md` entry written with commit SHA and evidence
- [ ] Scope fence honoured, or amendments recorded
- [ ] No secrets, tokens, or customer data in code, logs, or ledger entries

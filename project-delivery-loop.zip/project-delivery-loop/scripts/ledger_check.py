#!/usr/bin/env python3
"""Audit ledger consistency. Run at P9, before ending a session.

    python3 ledger_check.py --root /path/to/repo [--max-memory-age-days 14]

Exit codes: 0 clean, 1 problems found, 2 setup error.
Checks are mechanical on purpose - they catch the failure modes that make a
ledger untrustworthy, not the ones that need judgement.
"""
import argparse
import datetime as dt
import pathlib
import re
import sys

ID_RE = re.compile(r"^##+\s*(T|C|B|D)-(\d{4})\b", re.M)
TS_RE = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[+-]\d{2}:\d{2}")
LOOSE_TS_RE = re.compile(r"\b(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2}(:\d{2})?)\b")
TASK_BLOCK_RE = re.compile(r"^###\s*(T-\d{4})\s*—?\s*(.*)$", re.M)

CAPS = {"MEMORY.md": 400, "CHANGES.md": 1500, "TASKS.md": 900, "BUGS.md": 1200, "DECISIONS.md": 1200}
FILES = list(CAPS)


def read(root: pathlib.Path, name: str):
    p = root / name
    return p.read_text(encoding="utf-8") if p.exists() else None


def ids_in(text: str, kind: str):
    return [f"{k}-{n}" for k, n in ID_RE.findall(text or "") if k == kind]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--max-memory-age-days", type=int, default=14)
    args = ap.parse_args()

    root = pathlib.Path(args.root).expanduser().resolve()
    problems, warnings = [], []

    docs = {}
    for f in FILES:
        t = read(root, f)
        if t is None:
            problems.append(f"missing ledger: {f} (run ledger_init.py)")
        docs[f] = t or ""

    # 1. duplicate IDs
    for f, kind in (("TASKS.md", "T"), ("CHANGES.md", "C"), ("BUGS.md", "B"), ("DECISIONS.md", "D")):
        seen, dupes = set(), set()
        for i in ids_in(docs[f], kind):
            (dupes if i in seen else seen).add(i)
        for d in sorted(dupes):
            problems.append(f"{f}: duplicate id {d}")

    task_ids = set(ids_in(docs["TASKS.md"], "T"))
    bug_ids = set(ids_in(docs["BUGS.md"], "B"))
    dec_ids = set(ids_in(docs["DECISIONS.md"], "D"))
    archive = root / "docs" / "agent-archive"
    archived = ""
    if archive.is_dir():
        for p in archive.glob("*.md"):
            archived += p.read_text(encoding="utf-8", errors="ignore")
    known_tasks = task_ids | set(ids_in(archived, "T"))

    # 2. changes must reference a real task
    for block in re.split(r"(?=^##\s+C-\d{4})", docs["CHANGES.md"], flags=re.M):
        m = re.match(r"##\s+(C-\d{4})", block.strip())
        if not m:
            continue
        cid = m.group(1)
        refs = set(re.findall(r"T-\d{4}", block))
        if not refs:
            problems.append(f"CHANGES.md: {cid} references no task id")
        else:
            for r in refs:
                if r not in known_tasks:
                    warnings.append(f"CHANGES.md: {cid} references unknown task {r}")
        if "Commit:" not in block:
            warnings.append(f"CHANGES.md: {cid} has no commit sha")
        if "Verification" not in block:
            problems.append(f"CHANGES.md: {cid} has no verification evidence")

    # 3. DONE tasks need a change entry
    changes_text = docs["CHANGES.md"] + archived
    for block in re.split(r"(?=^###\s+T-\d{4})", docs["TASKS.md"], flags=re.M):
        m = TASK_BLOCK_RE.match(block.strip())
        if not m:
            continue
        tid = m.group(1)
        status = ""
        sm = re.search(r"^-\s*Status:\s*([A-Z_]+)", block, re.M)
        if sm:
            status = sm.group(1)
        if status == "DONE" and tid not in changes_text:
            problems.append(f"TASKS.md: {tid} is DONE but has no CHANGES.md entry")
        if status == "IN_PROGRESS" and re.search(r"^-\s*Owner:\s*(—|-|\s*)$", block, re.M):
            problems.append(f"TASKS.md: {tid} is IN_PROGRESS with no owner (unclaimed work)")
        if status == "BLOCKED" and "Notes:" not in block:
            warnings.append(f"TASKS.md: {tid} is BLOCKED with no notes on what was tried")
        if status not in {"", "BACKLOG", "PLANNED", "IN_PROGRESS", "BLOCKED", "IN_REVIEW", "DONE", "DROPPED"}:
            problems.append(f"TASKS.md: {tid} has unknown status '{status}'")

    # 4. bug hygiene
    for block in re.split(r"(?=^##\s+B-\d{4})", docs["BUGS.md"], flags=re.M):
        m = re.match(r"##\s+(B-\d{4})", block.strip())
        if not m:
            continue
        bid = m.group(1)
        st = re.search(r"^-\s*Status:\s*([A-Z_]+)", block, re.M)
        status = st.group(1) if st else ""
        if not re.search(r"^-\s*Repro:\s*\S", block, re.M):
            problems.append(f"BUGS.md: {bid} has no repro steps")
        if not re.search(r"^-\s*Severity:\s*S[1-4]", block, re.M):
            problems.append(f"BUGS.md: {bid} has no severity")
        if status == "FIXED":
            if not re.search(r"^-\s*Root cause:\s*\S", block, re.M):
                problems.append(f"BUGS.md: {bid} FIXED with no root cause")
            if not re.search(r"^-\s*Regression:\s*(?!—|-\s*$)\S", block, re.M):
                problems.append(f"BUGS.md: {bid} FIXED with no regression test")

    # 5. timestamps
    for f in FILES:
        for line in docs[f].splitlines():
            if "<ts>" in line or "<ISO-8601" in line:
                continue
            for m in LOOSE_TS_RE.finditer(line):
                if not TS_RE.search(line):
                    warnings.append(f"{f}: timestamp without offset -> {line.strip()[:70]}")
                    break
    now = dt.datetime.now(dt.timezone.utc)
    for f in FILES:
        for raw in TS_RE.findall(docs[f]):
            try:
                if dt.datetime.fromisoformat(raw) > now + dt.timedelta(hours=26):
                    problems.append(f"{f}: future timestamp {raw}")
            except ValueError:
                problems.append(f"{f}: unparseable timestamp {raw}")

    # 6. size caps
    for f, cap in CAPS.items():
        n = len(docs[f].splitlines())
        if n > cap:
            warnings.append(f"{f}: {n} lines exceeds cap {cap} - run ledger_rotate.py")

    # 7. memory freshness
    mem_ts = TS_RE.findall(docs["MEMORY.md"])
    all_ts = TS_RE.findall(docs["CHANGES.md"])
    if mem_ts and all_ts:
        try:
            newest_mem = max(dt.datetime.fromisoformat(t) for t in mem_ts)
            newest_chg = max(dt.datetime.fromisoformat(t) for t in all_ts)
            if (newest_chg - newest_mem).days > args.max_memory_age_days:
                warnings.append(
                    f"MEMORY.md last updated {newest_mem.date()} but changes land through "
                    f"{newest_chg.date()} - memory is drifting from reality"
                )
        except ValueError:
            pass

    # 8. secret smell test
    secret = re.compile(
        r"(?i)(api[_-]?key|secret|password|passwd|token|bearer\s+[A-Za-z0-9._-]{12,}|"
        r"AKIA[0-9A-Z]{16}|sk-[A-Za-z0-9]{16,}|-----BEGIN [A-Z ]*PRIVATE KEY)"
    )
    for f in FILES:
        for i, line in enumerate(docs[f].splitlines(), 1):
            if secret.search(line) and "<redacted>" not in line and "NAMES ONLY" not in line:
                warnings.append(f"{f}:{i}: possible secret - verify and redact -> {line.strip()[:60]}")

    # 9. dangling references
    body = docs["CHANGES.md"] + docs["TASKS.md"] + docs["BUGS.md"]
    for ref in sorted(set(re.findall(r"\bD-\d{4}\b", body))):
        if ref not in dec_ids and ref not in set(ids_in(archived, "D")):
            warnings.append(f"reference to unknown decision {ref}")
    for ref in sorted(set(re.findall(r"\bB-\d{4}\b", docs["CHANGES.md"] + docs["TASKS.md"]))):
        if ref not in bug_ids and ref not in set(ids_in(archived, "B")):
            warnings.append(f"reference to unknown bug {ref}")

    print(f"ledger_check: {root}")
    for p in problems:
        print(f"  FAIL  {p}")
    for w in warnings:
        print(f"  WARN  {w}")
    if not problems and not warnings:
        print("  clean")
    print(f"\n{len(problems)} problem(s), {len(warnings)} warning(s)")
    return 1 if problems else 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Bootstrap the five ledger files into a repository.

Never overwrites an existing file. Safe to re-run.

    python3 ledger_init.py --root /path/to/repo [--name "My App"] [--offset +05:30]
"""
import argparse
import datetime as dt
import pathlib
import sys

LEDGERS = ["MEMORY.md", "TASKS.md", "CHANGES.md", "BUGS.md", "DECISIONS.md"]


def now(offset: str) -> str:
    try:
        sign = 1 if offset[0] != "-" else -1
        hh, mm = offset[1:].split(":")
        tz = dt.timezone(sign * dt.timedelta(hours=int(hh), minutes=int(mm)))
    except Exception:
        tz = dt.timezone.utc
    return dt.datetime.now(tz).replace(microsecond=0).isoformat()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--name", default=None, help="project name; defaults to the repo dir name")
    ap.add_argument("--offset", default="+00:00", help="fixed UTC offset for all timestamps, e.g. +05:30")
    ap.add_argument("--templates", default=None, help="templates dir (default: ../templates)")
    args = ap.parse_args()

    root = pathlib.Path(args.root).expanduser().resolve()
    if not root.is_dir():
        print(f"error: {root} is not a directory", file=sys.stderr)
        return 2

    tpl = pathlib.Path(args.templates) if args.templates else pathlib.Path(__file__).resolve().parent.parent / "templates"
    if not tpl.is_dir():
        print(f"error: templates dir not found: {tpl}", file=sys.stderr)
        return 2

    name = args.name or root.name
    stamp = now(args.offset)
    created, skipped = [], []

    for f in LEDGERS:
        dest = root / f
        if dest.exists():
            skipped.append(f)
            continue
        text = (tpl / f).read_text(encoding="utf-8")
        text = text.replace("<PROJECT NAME>", name)
        text = text.replace("<ISO-8601 with offset>", stamp)
        dest.write_text(text, encoding="utf-8")
        created.append(f)

    (root / "docs" / "agent-archive").mkdir(parents=True, exist_ok=True)

    print(f"root:    {root}")
    print(f"created: {', '.join(created) or '(none)'}")
    print(f"skipped: {', '.join(skipped) or '(none)'}  (already present, untouched)")
    if created:
        print("\nNext: reconstruct MEMORY.md from the codebase rather than leaving the template.")
        print("      File it as T-0001 'Reconstruct project memory' in TASKS.md.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

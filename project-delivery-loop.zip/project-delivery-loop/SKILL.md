---
name: project-delivery-loop
description: Disciplined change-delivery loop for software projects — analyze and sequence the ask, research prior art, apply a necessity gate against over-engineering, plan, implement inside a scope fence, verify with real evidence, and maintain the MEMORY.md / TASKS.md / CHANGES.md / BUGS.md / DECISIONS.md ledger so any agent can resume cold. Use this whenever the user asks for a feature, change, fix, refactor, migration, or "add X to the app" in a codebase; whenever ledger files exist in the repo; and at the start and end of every session in such a repo — even if the user never mentions this workflow by name.
license: MIT
metadata:
  version: 1.0.0
---

# Project Delivery Loop

A repeatable loop for changing software without losing state, over-building, or
faking progress. Every change — one-line fix or new subsystem — goes through the
same ten phases at a rigor proportional to its risk tier.

The loop's memory lives in five ledger files at the repo root (configurable):

| File | Role | Write mode |
|---|---|---|
| `MEMORY.md` | Orientation snapshot: what the app is, how to run it, where things live, current state | Rewritten in place, capped |
| `TASKS.md` | Work queue with IDs, tiers, status, owner, dependencies | Edited in place |
| `CHANGES.md` | Append-only log of what shipped, with evidence and commit SHA | Append (newest first) |
| `BUGS.md` | Defect register with repro, root cause, fix reference | Append + status edits |
| `DECISIONS.md` | ADR-lite: what was chosen, what was rejected, and why | Append (newest first) |

`DECISIONS.md` is the file most teams skip and most regret skipping: without it
every new session re-runs the same research and re-proposes the same rejected
idea. It is what makes "don't over-engineer" enforceable instead of aspirational.

## The loop

| Phase | Name | Output | Skippable? |
|---|---|---|---|
| P0 | Orient | Cold-start context load + 5-line restatement | Never |
| P1 | Intake | Decomposed, sequenced units + risk tier | Never |
| P2 | Research | Prior art, in-repo and external | T0 only |
| P3 | Necessity gate | Minimal viable scope, or a logged rejection | Never |
| P4 | Plan | `TASKS.md` updated; approval for T2/T3 | Never |
| P5 | Implement | Code, inside a declared scope fence | Never |
| P6 | Verify | Test evidence: commands run, output seen | Never |
| P7 | Defects | `BUGS.md` entries, fixes, regression tests | If zero found |
| P8 | Log | `CHANGES.md` entry with SHA + evidence | Never |
| P9 | Memory + audit | `MEMORY.md` refresh, ledger check, handoff | Never |

Do not run phases out of order. The most common failure is jumping P1 → P5,
which produces code that solves the wrong ask, and P6 → P8 without evidence,
which produces a ledger that lies.

## P0 — Orient (every session, before answering anything)

Read in this order, then stop and restate:

1. `MEMORY.md` — whole file.
2. `TASKS.md` — everything not `DONE`.
3. `CHANGES.md` — the newest 3 entries.
4. `BUGS.md` — everything `OPEN`.
5. `DECISIONS.md` — scan titles; read any that touch today's ask.

If the files do not exist, this is a cold repo: run
`python3 scripts/ledger_init.py --root <repo>` , then reconstruct `MEMORY.md`
from the codebase (read the manifest, entry points, routes, schema, CI config,
README) rather than leaving it empty. A brownfield repo gets a bootstrap task
`T-0001 Reconstruct project memory`, not a blank template.

Then reply with a five-line orientation: what the app is, what state it is in,
what is open, what is blocked, what you believe today's ask is. Getting this
wrong out loud is cheap; getting it wrong silently is not.

## P1 — Intake and sequencing

Never start from the user's phrasing alone. Produce:

- **Restated ask** — in your words, including what you think is *implied*.
- **Ambiguities** — list them. Ask only the ones that would change the design;
  state a default for the rest and proceed.
- **Decomposition** — atomic units, each independently shippable and testable.
- **Sequence** — ordered by hard dependency (schema before API before UI before
  tests-that-need-both), then by risk (touch the risky, load-bearing thing first
  while there is room to back out), then by unblocking value.
- **Tier** — T0/T1/T2/T3 per `references/01-intake-and-tiering.md`.

State the sequence *and the reason for the order*. "A before B" without "because
B reads A's schema" is not a plan, it is a list.

## P2 — Research

Skip only for T0. Otherwise search both directions:

- **Inward first.** Grep the repo. Does a module, helper, hook, or migration
  already do 70% of this? Reusing an existing seam beats any external pattern.
- **Outward second.** How do successful, shipped products solve this? Look for
  the *shape* of the solution, its failure modes, and what parts of it are
  overkill at your scale.

Budget: T1 ≤ 5 sources, T2 ≤ 10, T3 ≤ 15. Stop when two consecutive sources add
nothing new (saturation) — not when you run out of curiosity. Full protocol and
the comparison table format: `references/02-research-and-necessity.md`.

## P3 — Necessity gate

The anti-over-engineering gate. A unit proceeds only if it passes all six:

1. **Traceable** — maps to a stated need, an open bug, or a measured problem.
   "Might be useful later" fails.
2. **Not already solved** — you have read the candidate existing modules and can
   name why each is insufficient.
3. **Minimal form** — you can name the bigger version you are deliberately *not*
   building.
4. **Dependency justified** — a new dependency must remove ≥100 lines you would
   otherwise write, or be security-critical (crypto, auth, parsers). Otherwise
   write the 20 lines.
5. **Rule of three** — no new abstraction, config layer, or plugin system before
   the third real repetition.
6. **Reversible** — you can state how to undo it. If undoing is expensive, it is
   T3 regardless of size.

Anything that fails gets a `DECISIONS.md` entry with status `REJECTED` and the
failing criterion. That entry is the point: it stops the same idea returning
next session as if it were new.

## P4 — Plan and approval

Write the units into `TASKS.md` with IDs, tier, dependencies, acceptance
criteria, and the file scope fence. Then:

- **T0/T1** — proceed.
- **T2/T3** — present the plan block and **wait**. Scope, files, tier, risks,
  what is explicitly out of scope, rollback. Do not begin editing while asking.

Acceptance criteria must be observable ("POST /verify returns 429 after 5
attempts in 60s"), not aspirational ("rate limiting works").

## P5 — Implement

One task at a time, status `IN_PROGRESS`, owner set. Rules:

- **Scope fence** — touch only files listed in the task. Needing another file is
  fine; silently touching it is not. Amend the task, note it, continue.
- **No drive-by refactors.** Spotted something ugly outside scope? `TASKS.md`,
  tier T1, move on.
- **No fabricated progress.** Never report a step as done that you did not run.
  If a command failed, the honest failure is the useful output.
- Commit as `type(scope): summary [T-0042]`.

## P6 — Verify

"Test it thoroughly" is not a plan; run the tiers in
`references/03-implement-and-verify.md` and record **evidence**: the exact
command, and the observed result. A task cannot reach `DONE` without it.

Hard rules:

- Never weaken, skip, mock-away, or delete a test to make a suite pass. If a
  test blocks you, either the code is wrong or the test is wrong — decide out
  loud in `DECISIONS.md`, never silently.
- Run the full suite, not just your file. "My test passes" is not "nothing
  broke".
- If it has a UI, list the manual smoke steps you actually clicked through.
- Three failed fix attempts on the same defect = stop, mark `BLOCKED`, write what
  you tried and what you ruled out, revert to the last green commit, escalate.

## P7 — Defects

Every defect found — during testing or reported later — gets a `BUGS.md` entry
before it gets a fix, so a bug fixed in 30 seconds still leaves a trace of what
was wrong. Each fix needs a **root cause** (not a symptom description) and a
**regression test** that fails on the old code. In-scope fixes land in the same
task; out-of-scope defects become new tasks — a bug is never a licence to expand
the change.

## P8 — Log

Append a `CHANGES.md` entry per task: timestamp, task ID, tier, what changed and
why, files touched, commit SHA, verification evidence, follow-ups. Schemas for
all five ledgers: `references/04-ledger-schemas.md`.

## P9 — Memory and audit

Refresh `MEMORY.md` only where reality moved — it is a snapshot, not a diary,
and it is capped (400 lines) precisely so the next agent will actually read it.
Then run `python3 scripts/ledger_check.py --root <repo>`, which catches the
failure modes that make ledgers untrustworthy: `DONE` tasks with no change
entry, changes referencing dead task IDs, duplicate IDs, future or malformed
timestamps, open bugs missing repro steps, stale memory, oversized files.

End every session with a handoff block: current branch, uncommitted state, the
single next action, and anything you learned that is not yet written down.

## Timestamps, IDs, hygiene

- Timestamps: ISO-8601 with offset, `2026-08-20T14:32:05+05:30`. Every entry.
  Pick one offset (local or UTC) and keep it consistent forever.
- IDs: `T-0001`, `C-0001`, `B-0001`, `D-0001`. Zero-padded, never reused, never
  renumbered.
- Every entry names its author: `Claude Opus 5 / Cursor / human`.
- **Never** write secrets, tokens, `.env` values, connection strings, customer
  data, or credential-bearing stack traces into a ledger. Redact as `<redacted>`.
  These files get committed and shared.

## Reference files

Read the one you need, when you need it:

- `references/01-intake-and-tiering.md` — tier definitions, decomposition and
  sequencing patterns, the plan block format.
- `references/02-research-and-necessity.md` — research protocol, source budget,
  prior-art comparison table, the necessity gate worked through examples.
- `references/03-implement-and-verify.md` — scope fence, test tiers, evidence
  format, rollback and blocked protocol, doc-drift checklist.
- `references/04-ledger-schemas.md` — exact entry schemas for all five files,
  status vocabularies, rotation and archiving rules.
- `references/05-multi-agent-and-hygiene.md` — concurrent agents, task claiming,
  merge-conflict avoidance, secret hygiene, cross-tool portability.
- `references/06-gap-analysis.md` — what this loop adds to the naive
  seven-step version and why each addition exists. Read when tempted to drop a
  phase.

Templates for the five ledgers are in `templates/`. Scripts in `scripts/` are
stdlib-only Python 3 with no install step.

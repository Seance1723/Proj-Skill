# project-delivery-loop

A portable discipline for changing software: analyse and sequence the ask,
research prior art, apply a necessity gate against over-engineering, plan,
implement inside a scope fence, verify with real evidence, and keep a ledger any
agent can resume from cold.

Ships as an **Agent Skill** (`SKILL.md`, the agentskills.io standard) plus
**adapter files** for tools that read instruction files instead of skills — so
the same rules load in Claude Code, Codex, Cursor, Copilot, Gemini CLI, Windsurf,
Cline, Roo, Amazon Q, Junie, Zed, and Aider.

## Install

```bash
chmod +x install.sh
./install.sh --repo /path/to/your/repo --init-ledgers --name "My App" --offset +05:30
```

Windows:

```powershell
.\install.ps1 -Repo C:\code\my-app -InitLedgers -Name "My App" -Offset "+05:30"
```

Add `--user` (`-User`) to also install the skill globally for your account.
Add `--dry-run` to see what it would touch. Re-running is safe: ledgers are
never overwritten, and adapter blocks are fenced with
`<!-- BEGIN project-delivery-loop -->` markers so they update in place.

Then **commit the files**. The loop travels with the repo, not with your machine.

## What lands where

| Tool | Path written | Mechanism |
|---|---|---|
| Codex, Cursor, Copilot, Gemini CLI, Cline, Amp, Warp, OpenCode | `.agents/skills/project-delivery-loop/` | Agent Skills (shared project dir) |
| Claude Code, Claude Cowork | `.claude/skills/…` + `CLAUDE.md` | Skill + memory file |
| OpenAI Codex | `.codex/skills/…` + `AGENTS.md` | Skill + instructions |
| GitHub Copilot | `.github/skills/…`, `.github/copilot-instructions.md` | Skill + repo instructions |
| Cursor | `.cursor/rules/delivery-loop.mdc` (`alwaysApply: true`) | Project rule |
| Gemini CLI / Code Assist | `GEMINI.md` | Context file |
| Windsurf | `.windsurf/rules/delivery-loop.md` | Rules dir |
| Cline | `.clinerules/delivery-loop.md` | Rules dir |
| Roo Code | `.roo/rules/delivery-loop.md` | Rules dir |
| Amazon Q Developer | `.amazonq/rules/delivery-loop.md` | Project rules |
| JetBrains Junie | `.junie/guidelines.md` | Guidelines |
| Zed | `.zed/rules.md` | Rules |
| Aider | `CONVENTIONS.md` | Conventions |
| Anything else | `AGENTS.md` | The open cross-tool standard |

The skill is the source of truth; every adapter carries the non-negotiable core
inline and points at `SKILL.md` for the detail. A tool that cannot load skills
still gets the loop; a tool that can gets the references and scripts too.

## What it creates in your repo

| File | Role |
|---|---|
| `MEMORY.md` | Cold-start snapshot: what the app is, how to run it, the map, invariants, gotchas. Capped at 400 lines |
| `TASKS.md` | Work queue: IDs, tier, owner, dependencies, scope fence, acceptance criteria |
| `CHANGES.md` | Append-only history with commit SHAs and verification evidence |
| `BUGS.md` | Defect register with repro, severity, root cause, regression test |
| `DECISIONS.md` | ADR-lite — including **rejections**, so settled arguments stay settled |
| `docs/agent-archive/` | Rotated older entries, referenced by ID range |

## Scripts (stdlib Python 3, no install)

```bash
python3 scripts/ledger_init.py   --root .                 # bootstrap, never overwrites
python3 scripts/ledger_check.py  --root .                 # audit; exit 1 on problems
python3 scripts/ledger_rotate.py --root . --dry-run       # archive old entries
```

`ledger_check.py` catches the things that quietly make a ledger untrustworthy:
`DONE` tasks with no change entry, changes citing dead task IDs, duplicate IDs,
timestamps without an offset or in the future, fixed bugs with no root cause or
regression test, unclaimed in-progress work, oversized files, memory drifting
behind reality, and probable secrets.

Wire it into CI or a pre-push hook once the habit is established:

```bash
python3 .agents/skills/project-delivery-loop/scripts/ledger_check.py --root . || exit 1
```

## Adopting on an existing project

Don't leave the `MEMORY.md` template in place — an empty memory is worse than
none, because the next agent trusts it. Run the installer, then ask your agent:

> Read the codebase and reconstruct MEMORY.md per the project-delivery-loop
> skill — stack, how to run it, the map, invariants, gotchas, current state.
> Then log the open threads you found as tasks.

## Layout

```
project-delivery-loop/
├── SKILL.md                  # the loop; loads on trigger
├── references/               # loaded on demand
│   ├── 01-intake-and-tiering.md
│   ├── 02-research-and-necessity.md
│   ├── 03-implement-and-verify.md
│   ├── 04-ledger-schemas.md
│   ├── 05-multi-agent-and-hygiene.md
│   └── 06-gap-analysis.md    # why each phase exists
├── templates/                # the five ledgers
├── scripts/                  # init, check, rotate
├── adapters/                 # per-tool instruction files
├── install.sh / install.ps1
└── README.md
```

## Tuning it

- Rename the skill: change the directory, the `name:` in `SKILL.md`, and the
  `$SKILL` variable in the installers.
- Change ledger location: they default to the repo root; if you move them, say so
  in `MEMORY.md → Pointers` and pass `--root` accordingly.
- Loosen or tighten tiers in `references/01-intake-and-tiering.md`. This is the
  knob that decides whether the process gets followed or abandoned — if the
  overhead feels theatrical on small changes, more things belong in T0/T1.

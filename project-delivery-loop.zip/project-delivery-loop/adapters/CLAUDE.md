# CLAUDE.md

Claude Code reads this file at session start. The delivery loop below is
mandatory for every change in this repository.

<!-- BEGIN project-delivery-loop -->
## Delivery loop (mandatory for every change)

Full spec: `.agents/skills/project-delivery-loop/SKILL.md`. Read it before the
first change of a session. Ledgers live at the repo root: `MEMORY.md`,
`TASKS.md`, `CHANGES.md`, `BUGS.md`, `DECISIONS.md`.

**P0 Orient** — before answering anything, read `MEMORY.md`, open items in
`TASKS.md`, the newest 3 `CHANGES.md` entries, `OPEN` bugs, and any relevant
decision. Restate in five lines what the app is, its state, and today's ask.

**P1 Intake** — restate the ask, name ambiguities, decompose into independently
shippable units, sequence them with stated reasons, assign a tier:
T0 trivial · T1 standard · T2 significant (new module/dep/schema/contract) ·
T3 irreversible (data, billing, secrets, infra).

**P2 Research** — skip only for T0. Grep the repo first for something that
already does 70% of this, then look outward at how shipped products solve it and
what parts of that are overkill here. Budget: T1 ≤5 sources, T2 ≤10, T3 ≤15;
stop at saturation.

**P3 Necessity gate** — proceed only if all six pass: traceable to a real need ·
not already solved by existing code · minimal form (name the bigger version you
are *not* building) · new dependency removes ≥100 lines or is security-critical ·
no new abstraction before the third repetition · reversible. A failure is logged
in `DECISIONS.md` as REJECTED so it is not re-proposed next session.

**P4 Plan** — write units into `TASKS.md` with IDs, tier, dependencies, scope
fence, out-of-scope, and observable acceptance criteria. **T2/T3 require an
explicit go-ahead before implementation** — present the plan and wait.

**P5 Implement** — one task `IN_PROGRESS` at a time, owner set. Touch only files
in the scope fence; record amendments. No drive-by refactors. Never report a
step as done that you did not run. Commit as `type(scope): summary [T-0042]`.

**P6 Verify** — run build, unit, integration, negative cases, the full suite, and
a manual smoke of the real user path. Record the exact commands and observed
results, plus an honest "Not covered" line. **Never weaken, skip, or delete a
test to get green.** Three failed fix attempts → revert to last green, set
`BLOCKED`, write what you tried and ruled out.

**P7 Defects** — log in `BUGS.md` *before* fixing, with repro, severity, and root
cause (mechanism, not symptom). Every fix needs a regression test that fails on
the old code. Out-of-scope defects become new tasks, never scope expansion.

**P8 Log** — append a `CHANGES.md` entry: timestamp, task ID, what and why, files,
commit SHA, verification evidence, follow-ups. Append-only; never edit history.

**P9 Memory + audit** — refresh `MEMORY.md` only where reality moved (hard cap
400 lines), run `python3 .agents/skills/project-delivery-loop/scripts/ledger_check.py --root .`,
and end with a handoff block: branch, tree state, next action, what you learned.

**Conventions** — ISO-8601 timestamps with a fixed offset (`2026-08-20T14:32:05+05:30`);
IDs `T-`/`C-`/`B-`/`D-` zero-padded to four, never reused; every entry names its
author. Never write secrets, `.env` values, or customer data into a ledger.
<!-- END project-delivery-loop -->

<#
.SYNOPSIS
  Install the project-delivery-loop skill and per-tool adapter files (Windows).
.EXAMPLE
  .\install.ps1 -Repo C:\code\my-app -InitLedgers -Name "My App" -Offset "+05:30"
#>
param(
  [Parameter(Mandatory = $true)][string]$Repo,
  [switch]$User,
  [switch]$InitLedgers,
  [string]$Name = "",
  [string]$Offset = "+00:00"
)

$ErrorActionPreference = "Stop"
$Src = Split-Path -Parent $MyInvocation.MyCommand.Path
$Skill = "project-delivery-loop"
$Repo = (Resolve-Path $Repo).Path

function Copy-Skill($SkillsDir) {
  $dest = Join-Path $SkillsDir $Skill
  New-Item -ItemType Directory -Force -Path $SkillsDir | Out-Null
  if (Test-Path $dest) { Remove-Item -Recurse -Force $dest }
  Copy-Item -Recurse $Src $dest
  Remove-Item -Force (Join-Path $dest "install.sh"), (Join-Path $dest "install.ps1") -ErrorAction SilentlyContinue
  Write-Host "  skill  -> $dest"
}

function Write-Block($Target, $SrcFile) {
  $dir = Split-Path -Parent $Target
  if ($dir) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
  $block = Get-Content $SrcFile -Raw
  if (Test-Path $Target) {
    $cur = Get-Content $Target -Raw
    if ($cur -match '(?s)<!-- BEGIN project-delivery-loop -->.*?<!-- END project-delivery-loop -->') {
      $new = [regex]::Replace($cur,
        '(?s)<!-- BEGIN project-delivery-loop -->.*?<!-- END project-delivery-loop -->',
        [System.Text.RegularExpressions.MatchEvaluator] { param($m) $block })
      Set-Content $Target $new -NoNewline
      Write-Host "  update -> $Target"; return
    }
    Add-Content $Target "`n$block"; Write-Host "  append -> $Target"; return
  }
  Set-Content $Target $block -NoNewline
  Write-Host "  create -> $Target"
}

Write-Host "Installing $Skill into $Repo`n"
Write-Host "Skill (Agent Skills standard):"
foreach ($d in @(".agents\skills", ".claude\skills", ".codex\skills", ".github\skills")) {
  Copy-Skill (Join-Path $Repo $d)
}

Write-Host "`nAdapters:"
$A = Join-Path $Src "adapters"
$core = Join-Path $A "AGENTS.md"
$targets = @(
  "AGENTS.md", "CLAUDE.md", "GEMINI.md", "CONVENTIONS.md",
  ".github\copilot-instructions.md", ".windsurf\rules\delivery-loop.md",
  ".clinerules\delivery-loop.md", ".roo\rules\delivery-loop.md",
  ".amazonq\rules\delivery-loop.md", ".junie\guidelines.md", ".zed\rules.md"
)
foreach ($t in $targets) { Write-Block (Join-Path $Repo $t) $core }
New-Item -ItemType Directory -Force -Path (Join-Path $Repo ".cursor\rules") | Out-Null
Copy-Item (Join-Path $A "cursor-project-delivery-loop.mdc") (Join-Path $Repo ".cursor\rules\delivery-loop.mdc") -Force
Write-Host "  create -> .cursor\rules\delivery-loop.mdc"

if ($User) {
  Write-Host "`nUser scope:"
  foreach ($d in @("$HOME\.claude\skills", "$HOME\.codex\skills", "$HOME\.agents\skills")) { Copy-Skill $d }
}

if ($InitLedgers) {
  Write-Host "`nLedgers:"
  $a = @("$Src\scripts\ledger_init.py", "--root", $Repo, "--offset", $Offset)
  if ($Name) { $a += @("--name", $Name) }
  & python3 @a
}

Write-Host @"

Done.

Next:
  1. Commit these files - the loop is only shared if the repo carries it.
  2. For an existing project, reconstruct MEMORY.md from the codebase and file
     it as T-0001 rather than leaving the template.
  3. Verify: python3 .agents\skills\$Skill\scripts\ledger_check.py --root .
"@
